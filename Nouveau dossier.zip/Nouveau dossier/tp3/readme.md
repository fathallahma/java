# TP3

## Auteurs

 -Manal Laghmich
 -Reda Id idtaleb

 groupe : 4

## Introduction

Le TP a pour but de découvrir la documentation et la compilation sur java
et de savoir corriger les éventuelles erreurs.

## HOW TO


### récupération des données

Pour récupérer les données du projet, suivez les étapes suivantes :

* Si vous avez déjà une version locale du dépôt Git :
    * il vous suffit d'exécuter la commande shell suivante :
        ``` bash
        $ git pull
        ```
    Vous aurez ensuite accès à tous les fichiers du TP, et vous pourrez l'ouvrir dans
    un éditeur de texte.


* Si vous n'avez pas encore de version locale du dépôt :
    * Exécutez la commande suivante pour créer une version locale du dépôt dans
    le dossier *dossier-tp* :
        ```bash
        $ git clone https://gitlab-etu.fil.univ-lille1.fr/laghmich/laghmich-idtaleb-poo.git dossier-tp
        ```
        (**Attention**, le dossier doit être vide originellement)

    * Si vous préférez utiliser votre clé SSH (si elle est configurée sur votre
      [compte](https://docs.gitlab.com/ee/gitlab-basics/create-your-ssh-keys.html)) :

        ```bash
        $ git clone git@gitlab-etu.fil.univ-lille1.fr:laghmich/laghmich-idtaleb-poo.git
        ```
    Vous aurez de cette manière accès aux différents fichiers du projet. Pour mettre
     à jour ces fichiers, utilisez la commande précisée ci-dessus.

### Generation de la documentation
* Pour gener la documentation, passez la commande suivante :
  * pour example:
  ```bash
  $ javadoc -d ../docs -subpackages example
  ```
  * pour date:
  ```bash
  $ javadoc -d ../docs -subpackages date
  ```

 Pour la consulter, la documentation se trouvera dans le fichier docs.

### Compilation des classes

* Pour compiler une classe, placez-vous dans le dossier tp4/fichiers-tp3-bike/fichiers-tp
 et éxécutez la commande suivante:

  ```bash
  $ javac NomDeLaClasse.java
  ```
  *  exemple: Pour compiler la classe BikeStation,éxécutez la commande :

  ```bash
  $ javac BikeStation.java
  ```

### Compilation des classes de test

* Pour compiler une classe de test, placez-vous dans le dossier tp4/fichiers-tp3-bike/fichiers-tp
et éxécutez la commande suivante:

  ```bash
  $ javac -classpath test-1.7.jar test/NomDeLaClasseDeTest.java
  ```
  *  exemple: Pour compiler la classe BikeStationTest ,éxécutez la commande :

  ```bash
  $ javac -classpath test-1.7.jar test/BikeStationTest.java
  ```

### execution des tests
* Pour éxécuter les tests, éxécutez la commande suivante:
  ```bash
  $ java -jar test-1.7.jar NomDeLaClasseDeTest
  ```
  * exemple: pour éxécuter le code de la classe de test BikeStationTest, il faut passer la commande :
  ```bash
  $ java -jar test-1.7.jar BikeStationTest
  ```

### execution du programme

* Pour éxécuter le programme, éxécutez la commande suivante:
  ```bash
  $ java NomDeLaClasseMain.java
  ```
  exemple :
  ```bash
  $ java BikeMain.java
  ```
