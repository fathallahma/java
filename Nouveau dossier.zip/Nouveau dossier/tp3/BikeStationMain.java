
public class BikeStationMain {

	public static void main(String[] args) {
		if(args.length < 1){
			  System.out.println("Usage: java BikeStationMain <anInt>");
			  return;
			}
		BikeStation station = new BikeStation("station",10);
		Bike bike1 = new Bike("b001",BikeModel.CLASSICAL);
		Bike bike2 = new Bike("b002",BikeModel.ELECTRIC);
		station.dropBike(bike1);
		station.dropBike(bike2);

		int n=Integer.parseInt(args[0]);
		Bike res=station.takeBike(n);
		
		if(res!=null) {
		    System.out.println("You have taken the bike " + res.getId() + " for a rental price of " + Bike.PRICE);
		}
		else {
			System.out.println("There's no bike at the position " + args[0]);
		}
		
		
	}
}
