
public class BikeStation {

	private String name;
	private int capacity;
	private Bike[] slots;
	
    /**
     * Creates a bike station with a certain capacity and a name
     * @param name the name of the bike station
     * @param capacity the capacity of the bike station
     */
	public BikeStation(String name, int capacity) {
	    this.name=name;
	    this.capacity=capacity;
	    this.slots=new Bike[capacity];
	}


    /**
     * returns the name of the bike station
     * @return the name of the bike stations
     */
	public String getName() {
		return this.name;
	}

    /**
     * returns the capacity of the bike station
     * @return the capacity of the bike stations
     */
	public int getCapacity() {
		return this.capacity;
	}

    /**
     * returns the number of bikes that are in the bike station
     * @return the number of bikes that are in the bike station
     */
	public int getNumberOfBikes() {
		int cpt=0;
	    for(int i=0;i<this.capacity;i++) {
	    	if (this.slots[i]!=null){
	    		cpt++;
	    	}
	    }
		return cpt;
	}

    
    /**
     * return the first free slot in the bike station
     * if no free slots are available it returns -1
     * @return the index of the first free slot or -1 if no free slots are available
     */
	public int firstFreeSlot() {
		for(int i=0;i<this.capacity;i++) {
			if (this.slots[i]==null){
				return i;
	    	}
	    }	    
		return -1;
	}
	
    /**
     * drops the bike in the bike station an returns a boolean that indicates if the bike was dropped or not
     * @return true if the bike is dropped in the bike station, false if not
     */
	public boolean dropBike(Bike bike) {
		if (this.firstFreeSlot()!=-1) {
			this.slots[this.firstFreeSlot()]=bike;
			return true;
		}
		else {
			return false;
		}
	}
	
	
	
    /**takes the bike from the bike station and returns it
     * @param i the index of the slot
     * @return the bike or null if no bike is placed in that slot
     */
	public Bike takeBike(int i) {
	    if ((i<this.slots.length) && (i>=0) && (this.slots[i]!=null)){
        Bike bike = this.slots[i];
        this.slots[i] = null;
        return bike;
      }
	   else return null;
	}
	


	
	
}
