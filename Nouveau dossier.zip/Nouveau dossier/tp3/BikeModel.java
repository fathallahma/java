

/**
 * The different model of bikes.
 * 
 * @author JC
 *
 */
public enum BikeModel {
	CLASSICAL, ELECTRIC, TANDEM;
}
