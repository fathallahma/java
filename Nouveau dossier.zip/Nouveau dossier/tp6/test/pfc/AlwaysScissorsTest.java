package pfc;
import static org.junit.Assert.*;
import org.junit.Test;

import pfc.Shape;
import pfc.strategy.AlwaysScissors;
import pfc.strategy.Strategy;

public class AlwaysScissorsTest {
	/** tests if getShape returns the rightShape*/
	@Test
	public void testGetShape() {
		Strategy strategy1 = new AlwaysScissors();
		assertEquals(Shape.SCISSORS,strategy1.getShape());
	}
	
	public static junit.framework.Test suite() {
	      return new junit.framework.JUnit4TestAdapter(AlwaysScissors.class);
	  }
}
