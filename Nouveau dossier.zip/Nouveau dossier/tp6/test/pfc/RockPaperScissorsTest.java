package pfc;
import static org.junit.Assert.*;
import org.junit.Test;

import pfc.Shape;
import pfc.strategy.RockPaperScissors;
import pfc.strategy.Strategy;


public class RockPaperScissorsTest {
	/** tests if getShape returns the rightShape*/
	@Test
	public void testGetShape() {
		Strategy strategy1 = new RockPaperScissors();
		assertEquals(Shape.ROCK,strategy1.getShape());
		assertEquals(Shape.PAPER,strategy1.getShape());
		assertEquals(Shape.SCISSORS,strategy1.getShape());
		assertEquals(Shape.ROCK,strategy1.getShape());

	}
	
	public static junit.framework.Test suite() {
	      return new junit.framework.JUnit4TestAdapter(pfc.RockPaperScissorsTest.class);
	  }
}
