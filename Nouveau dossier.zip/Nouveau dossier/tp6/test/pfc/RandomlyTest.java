package pfc;
import static org.junit.Assert.*;
import org.junit.Test;

import pfc.Shape;
import pfc.strategy.Randomly;
import pfc.strategy.Strategy;

public class RandomlyTest {
	/** tests if getShape returns the rightShape*/
	@Test
	public void testGetShape() {
		Strategy strategy1 = new Randomly();
		assertTrue(strategy1.getShape()== Shape.PAPER || strategy1.getShape()== Shape.ROCK || strategy1.getShape()==Shape.SCISSORS);
	}
	
	public static junit.framework.Test suite() {
	      return new junit.framework.JUnit4TestAdapter(RandomlyTest.class);
	  }
}