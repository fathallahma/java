package pfc;
import static org.junit.Assert.*;
import org.junit.Test;

public class ShapeTest {
	/** tests if compareWith returns the right values */
	@Test
	public void testCompareWith() {
		
		Shape s1=Shape.PAPER;
		Shape s2=Shape.PAPER;
		Shape s4=Shape.ROCK;
		assertEquals(0,s1.compareWith(s2));
		assertEquals(-1,s4.compareWith(s1));
		assertEquals(1,s1.compareWith(s4));

				
	}
	
	
	
	
	public static junit.framework.Test suite() {
	      return new junit.framework.JUnit4TestAdapter(pfc.ShapeTest.class);
	  }
}
