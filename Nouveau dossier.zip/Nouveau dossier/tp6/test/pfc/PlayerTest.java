package pfc;
import static org.junit.Assert.*;
import org.junit.Test;
import pfc.strategy.*;

public class PlayerTest{

	  /**tests the creation of the player*/
	  @Test
	  public void PlayerCreation(){
	    Strategy strategy = new Randomly();
	    Player player = new Player("Manal",strategy);
	    assertEquals(0,player.getPoints());
	    assertEquals("Manal", player.getName());
	    assertEquals(strategy,player.getStrategy());
	  }

	  /** tests if play returns the right shape depending on the strategy*/
	  @Test
	  public void testPlay(){
	    Strategy strategy = new AlwaysScissors();
	    Player player = new Player("Manal",strategy);
	    assertEquals(Shape.SCISSORS,player.play());
	  }
	  
	  /** tests if addPoints adds the right amount of points given in parameters*/
	  @Test
	  public void addPointsTest(){
	    Player player = new Player("Manal",new Randomly());
	    assertEquals(0,player.getPoints());
	    player.addPoints(2);
	    assertEquals(2,player.getPoints());
	    player.addPoints(3);
	    assertEquals(5,player.getPoints());
	  }


	  public static junit.framework.Test suite() {
	      return new junit.framework.JUnit4TestAdapter(PlayerTest.class);
	  }
	}

