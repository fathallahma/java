package pfc;
import static org.junit.Assert.*;
import org.junit.Test;
import pfc.strategy.*;
public class GameTest {

	/**tests getWinner if it returns the right winner*/
	@Test
	public void testGetWinner() {
		Strategy strategy1 = new AlwaysScissors();
		Player player1 = new Player ("Manal",strategy1);
		Strategy strategy2 = new AlwaysScissors();
		Player player2 = new Player ("Reda",strategy2);
		player1.addPoints(10);
		player2.addPoints(5);
		Game game= new Game(player1,player2);
		assertEquals(player1,game.getWinner());
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	  public static junit.framework.Test suite() {
	      return new junit.framework.JUnit4TestAdapter(pfc.GameTest.class);
	  }
}
