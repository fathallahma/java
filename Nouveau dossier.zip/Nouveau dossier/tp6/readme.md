# TP 6

## Auteurs

 -Manal Laghmich
 -Reda Id idtaleb

 groupe : 6

## Introduction

Dans ce TP, nous allons modéliser le jeu du pierre-feuille-cisseaux (rock-paper-scissors).

Pierre-papier-ciseaux est un jeu effectué avec les mains et opposant un ou plusieurs joueurs. Les deux joueurs choisissent simultanément un des trois coups possibles en le symbolisant de la main. De façon générale, la pierre bat les ciseaux (en les émoussant), les ciseaux battent la feuille (en la coupant), la feuille bat la pierre (en l'enveloppant). Ainsi chaque coup bat un autre coup, fait match nul contre le deuxième (son homologue) et est battu par le troisième.

Le joueur gagnant est celui qui a le plus de points à la fin du nombre de manches choisies. Sachant qu'un coup gagnant vaut 2 points, un coup égalité vaut 1 point et un coup perdant ne ramène aucun point.

Dans ce TP, nous nous sommes servis d'un Makefile qui permettra de faciliter l'exécution de commandes.

Nous avons un package pfc, composé de 2 subpackages strategy et util qui contient le subpackage io.

Dans le package pfc.util.io, nous avons la classe Input qui nous est fournie.

Dans le package pfc.strategy nous disposons de plusieurs classes, formant une interface.

La classe Strategy, est l'interface, grâce à elle, on pourra avoir différent mode de jeux comme:

- AlwaysScissors qui fait jouer l'ordinateur avec uniquement des coups SCISSORS.
- HumanStrategy qui permet à l'utilisateur de choisir lui-même ses coups et jouer contre une autre strategy.
- Randomly qui permet à l'ordinateur de choisir ses coups de facon aléatoire.
- RockPaperScissors qui permet à l'utilisateur de toujours joué de facon ordonné et récurrente ROCK puis PAPER et enfin SCISSORS

Enfin le package pfc composé de:

- Player qui module un joueur avec son nom, son nombre de points et la strategy choisie.

- Shape une classe de type enum, qui permet de modéliser les 3 mouvements du jeu, rock paper et scissors.

- Game qui permet de generer le jeu,attribuer les points aux joueurs et afficher le gagnant.


## HOW TO


### récupération des données

Pour récupérer les données du projet, suivez les étapes suivantes :

* Si vous avez déjà une version locale du dépôt Git :
    * il vous suffit d'exécuter la commande shell suivante :
        ``` bash
        $ git pull
        ```
    Vous aurez ensuite accès à tous les fichiers du TP, et vous pourrez l'ouvrir dans
    un éditeur de texte.


* Si vous n'avez pas encore de version locale du dépôt :
    * Exécutez la commande suivante pour créer une version locale du dépôt dans
    le dossier *dossier-tp* :
        ```bash
        $ git clone https://gitlab-etu.fil.univ-lille1.fr/laghmich/laghmich-idtaleb-poo.git dossier-tp
        ```
        (**Attention**, le dossier doit être vide originellement)

    * Si vous préférez utiliser votre clé SSH (si elle est configurée sur votre
      [compte](https://docs.gitlab.com/ee/gitlab-basics/create-your-ssh-keys.html)) :

        ```bash
        $ git clone git@gitlab-etu.fil.univ-lille1.fr:laghmich/laghmich-idtaleb-poo.git
        ```
    Vous aurez de cette manière accès aux différents fichiers du projet. Pour mettre
     à jour ces fichiers, utilisez la commande précisée ci-dessus.

### Generation de la documentation
* Pour gener la documentation,Placez-vous dans le dossier tp6/src et passez la commande suivante :
  ```bash
  $ javadoc -d ../docs -subpackages battleship
  ```
 Pour la consulter, ouvrez le fichier index.html qui se trouve dans le dossier docs.

### Compilation des sources du projet (à faire en premier)

* Pour compiler les sources du projet, placez-vous a la racine du projet et passez les commandes suivantes :

  ```bash
  $ mkdir classes
  ```
  Ensuite, mettez vous dans le dossier src et passez la commande suivante:
    ```bash
    $ javac pfc/*.java -d ../classes

    ```

### Compilation et execution des tests

* Pour compiler une classe de test, placez-vous dans le dossier tp6/
et éxécutez la commande suivante:

  ```bash
  $ javac -classpath test-1.7.jar test/NomDeLaClasseDeTest.java
  ```
  *  exemple: Pour compiler la classe ShipTest ,éxécutez la commande :

  ```bash
  $ javac -classpath test-1.7.jar test/pfc/ShapeTest.java
  ```
* Pour executer une classe de test, placez-vous dans le dossier tp6/
et éxécutez la commande suivante:

  ```bash
  $ java -jar test-1.7.jar NomDeLaClasseDeTest
  ```
  *  exemple: Pour executer la classe ShipTest ,éxécutez la commande :
  ```bash
  $ java -jar test-1.7.jar ShapeTest
  ```

### Execution du programme avec le .jar executable

  placez-vous dans le dossier tp6/classes et ensuite, passez la commande suivante:

  ```bash 
  $ jar cvfm ../pfc.jar ../manifest-pfc pfc
  ```   
	ensuite placez vous au dossier tp6 et passez la commande suivante suivie du nombre de parties que vous voulez jouer :
  ```bash 
	$ java -jar pfc.jar 
  ```

### Execution du programme sans le .jar executable
placez-vous dans le dossier tp6/classes et ensuite, passez la commande suivante:
  ```bash
  $ java -classpath classes pfc.Main
  ```  
suivie par: le nombre de parties que vous voulez jouer.
* exemple: Pour jouer 2 parties passez la commande suivante:
  ```bash
  $ java -classpath classes pfc.Main 2
  ```  


### Usage du makefile

Le Makefile se trouvant dans le répertoire TP6, il faut y accéder par la commande cd TP6 après avoir récupéré le depot distant grâce à git pull, toutes les commandes du Makefile se font dans le répertoire.

##### Compilation des sources
  Pour compiler les sources du projet, placez-vous a la racine du projet et passez las commande suivante pour compiler toutes les classes du projets :
  ```bash
  $ make compileAll
  ```  
  Pour compiler une seule classe passez la commande :
  ```bash
  $ make compile'NomDeLaClasse'
  ```  
  exemple:
  ```bash
  $ make compileShape
  ```  
##### Generation de la doc
  Pour generer la doc , passez la commande suivante:
  ```bash
  $ make doc
  ```  
Un dossier docs est alors créé dans TP6, dans ce fichier se trouvent plusieurs fichiers en .html, ouvrir le fichier index.html vous permet de consulter la doc.

##### Execution et compilation des tests
La commande suivante permet de compiler et d'executer les tests du projet:
  ```bash
  $ make testAll
  ```  
  Pour compiler et executer une seule classe de test passez la commande :
  ```bash
  $ make test'NomDeLaClasse'
  ```  
  **Attention !** La compilation des tests exige normalement que les fichiers sources soient d'abord compilés,.

##### Execution du programme avec le .jar executable

  La commande suivante permet de créer le fichier example.jar executable et de l'executer:
  ```bash
  $ make archive
  ```

##### Execution du programme sans le .jar executable

  ```bash
  $ make pfc
  ```  

##### Nettoyage du TP6
La commande suivante supprime le dossier classes, le dossier docs, le fichier .jar et les fichiers .class, ces fichiers pouvant tous être recréés avec les commandes ci-dessus :
  ```bash
  $ make clean
  ```  
