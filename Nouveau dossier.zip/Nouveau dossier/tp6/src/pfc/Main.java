package pfc;

import pfc.util.io.Input;
import pfc.strategy.HumanStrategy;
import pfc.strategy.Randomly;

public class Main {
	
	public static void main(String[] args) {

		  System.out.println("type your first name");
		  String humanName = new Input().readString();
		  int n;
		  if (args.length == 0){
			  n=3;
			  System.out.println("You didn't precise the number of rounds, You'll play 3 rounds\n");}
		  else{ n = Integer.valueOf(args[0]);}

		  Player randomPlayer = new Player("computer",new Randomly());
		  Player humanPlayer  = new Player(humanName,new HumanStrategy());

		  Game   game  = new Game(humanPlayer, randomPlayer);
		  game.play(n);
		}
}
