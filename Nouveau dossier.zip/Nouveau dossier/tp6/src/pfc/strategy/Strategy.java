package pfc.strategy;

import pfc.Shape;
/** the strategy of the game*/
public interface Strategy {
	/**returns the player's move
	*@return the player's move
	*/
	public Shape getShape();

}
