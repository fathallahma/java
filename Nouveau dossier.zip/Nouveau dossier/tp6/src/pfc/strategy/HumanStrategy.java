package pfc.strategy;

import pfc.Shape;
import pfc.util.io.*;

/** a class of a strategy : the player chooses his move by typing on the keyboard r, p or s*/
public class HumanStrategy implements Strategy{

	/** asks the player to choose a move by typing on the keyboard r, p or s and returns it
	*@return the move chosen by the player
	*/
	@Override
	public Shape getShape() {
		  String choice;
		  Shape s=null;
		  System.out.println("Choose your move :\n");
		  System.out.println("to choose Rock type : r \n");
		  System.out.println("to choose Paper type : p \n");
		  System.out.println("to choose scissors type : s \n");
		  while((s != Shape.PAPER)&& (s!=Shape.ROCK)&&(s!=Shape.SCISSORS) ){
			  choice=Input.readString();
			  choice = choice.toLowerCase();
		  
			  if (choice.equals("r")){s= Shape.ROCK;}
			  else if (choice.equals("p")){s= Shape.PAPER;}
			  else if (choice.equals("s")){s= Shape.SCISSORS;}
			  else {System.out.println("Please type r, p or s !!!!");}

		  }
		  	return s;
	}
		  
	
	
	
	

}
