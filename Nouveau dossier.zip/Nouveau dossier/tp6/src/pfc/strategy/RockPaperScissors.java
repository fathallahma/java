package pfc.strategy;

import pfc.Shape;

/** a class of a strategy : the player plays rock , paper , scissors and keeps repeating the same thing until the end of the game*/
public class RockPaperScissors implements Strategy{
	
	int cpt;
	/**returns the player's move
	*@return the player's move
	*/
	@Override
	public Shape getShape() {
		  if (cpt % 3 == 0){
		      cpt++;
		      return Shape.ROCK;
		    }
		    else if (cpt % 3 == 1){
		      cpt++;
		      return Shape.PAPER;
		    }
		    else {
		      cpt++;
		      return Shape.SCISSORS;}		
	}
	
	

}
