package pfc.strategy;

import pfc.*;
/** a class of a strategy : the player always chooses scissors*/

public class AlwaysScissors implements Strategy {
	
	/**returns the player's move
	*@return the player's move
	*/

	@Override
	public Shape getShape() {
		return Shape.SCISSORS;
	}

}
