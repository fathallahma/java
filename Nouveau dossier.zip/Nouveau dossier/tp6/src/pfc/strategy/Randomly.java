package pfc.strategy;

import pfc.*;
import java.util.Random;

/** a class of a strategy : the player chooses random moves */

public class Randomly implements Strategy{

	private final static Random RAND =new Random();
	
	/** returns the player's random move
	*@return the player's moves
	*/
	@Override
	public Shape getShape() {
	    int alea=RAND.nextInt(3);
	    return Shape.values()[alea];
	}

	
}
