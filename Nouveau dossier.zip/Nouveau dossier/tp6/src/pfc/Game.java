package pfc;

/** a class for the Game*/
public class Game{
    private Player player1;
    private Player player2;
    private int nbParts;
    
    /** creates a game with two players given in parameter
    *@param player1 first player
    *@param player2 second player
    */
    public Game(Player player1, Player player2){
        this.player1 = player1;
        this.player2 = player2;
    }
    
    /** makes the players play one round*/
    public void playOneRound(){
        Shape s1 = player1.play();
        Shape s2 = player2.play();
        String n1=player1.getName();
        String n2=player2.getName();
        System.out.println(n1+" has played "+s1+"\n");
        System.out.println(n2+" has played "+s2+"\n");
        givePoints(s1,s2);

    }

    /** gives points to players after a round
    *@param s1 the move of the first player
    *@param s2 the move of the second player
    */
    private void givePoints(Shape s1, Shape s2) {
    	   String n1=player1.getName();
    	   String n2=player2.getName();
    	   
    	   if (s1.compareWith(s2)==0){
    		    player1.addPoints(1);
    		    player2.addPoints(1);
    		    System.out.println("TIE\n");
    	   }
    	   	else if (s1.compareWith(s2)==1){
    		    player1.addPoints(2);
    		    System.out.println(n1+" wins the round and earns 2 points\n");
    		}
    		  else {
    		  player2.addPoints(2);
    		  System.out.println( n2+" wins the round and earns 2 points\n");
    		  }
    		System.out.println("the score now is "+n1+"="+player1.getPoints()+"-"+n2+"="+player2.getPoints()+"\n");
   }
    	   
    	   
    /** makes the players play a certain number of rounds given in parameter
    *@param nbParts the number of rounds
    *@return the winner of the game
    */
    public Player play(int nbParts){
        int i = 0;
        while(i < nbParts) {
            playOneRound();
            i++;

        }
        String n1=player1.getName();
        String n2=player2.getName();
        if(this.getWinner()==player1){
          System.out.println("THE WINNER IS "+n1+"\n");
        }
        else if(this.getWinner()==player2){
          System.out.println("THE WINNER IS "+n2+"\n");
        }
        else {System.out.println("THE MATCH WAS A DRAW\n");}
        return this.getWinner();
    }
    
    /** returns the winner of the Game
    *@return the winner of the game*/
    public Player getWinner (){
      int nbPoints1=this.player1.getPoints();
      int nbPoints2=this.player2.getPoints();
      if(nbPoints1<nbPoints2){
        return this.player2;
      }
        else if (nbPoints1>nbPoints2){
          return this.player1;
      }
      else {return null;}
    }

    /** returns the number of rounds to play
     * @return the number of rounds
     */
    public int getNbParts() {
        return nbParts;
    }
    
    /** sets the number of rounds to play
     * @param nbParts the number of rounds to play
     */
    public void setNbParts(int nbParts) {
        this.nbParts = nbParts;
    }
    
}