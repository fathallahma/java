package pfc;

import pfc.strategy.Strategy;
/** A class that creates players*/
public class Player {
	/** the player's name*/
    private String name;
    /** the player's strategy*/
    private Strategy strategy;
    /** the player's points*/
    private int points;

    /**creates a player with a strategy and a name given in parameters
    *@param strategy the strategy of the player
    *@param name the name of the player
    */
    public Player(String name, Strategy strategy){
        this.name = name;
        this.strategy = strategy;
        this.points = 0;
    }

    /**returns the name of the player
    *@return the name of the player
    */
    public String getName() {
        return name;
    }
    /* sets the player's name
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**returns the player's strategy
    *@return the player's strategy*/
    public Strategy getStrategy() {
        return strategy;
    }
    /* sets the player's strategy
     * @param strategy the strategy to set
     */
    public void setStrategy(Strategy strategy) {
        this.strategy = strategy;
    }

    /**returns the player's number of points
    *@return the player's number of points*/
    public int getPoints() {
        return points;
    }
    /* sets the player's points
     * @param points the points to set
     */
    public void setPoints(int points){
        this.points = points;
    }
    
    /** adds points to the player
    *@param nbPoints the player's number of Points*/
    public void addPoints(int nbPoints){
      this.points=this.points+nbPoints;
    }
    
    /**returns the shape chosen by the player depending on his Strategy
    *@return the chosen Shape*/
    public Shape play(){
        return this.strategy.getShape();
    }

    
}