package pfc;

public enum Shape {
    PAPER,
    ROCK,
    SCISSORS;

	/** compares two shapes and returns an integer
	*@param shape a shape to compare with
	*@return 0,1 or -1
	*<ul>
	*<li>0 if the two shapes are equal</li>
	*<li>1 if the shape shape makes a player lose </li>
	*<li>-1 if the shape shape makes a player win </li>
	*</ul>
	*/
    public int compareWith(Shape shape){
    	
        if (this == shape) {
            return 0;
        }
        else {
          if (this == ROCK){
            if (shape == PAPER){
        
              return -1;
            }
          }
          else if (this == PAPER){
            if (shape == SCISSORS){

              return -1;}
          }
          else{
            if (shape == ROCK){

              return -1;
            }
          }
        }
        return 1;
        }
    

}
