# TP 7

## Auteurs

 -Manal Laghmich
 -Reda Id idtaleb

 groupe : 6

## Introduction

Ce TP portait sur l'implémentation des agences de location, vues en TD. Une agence peut contenir plusieurs véhicules que des clients peuvent louer, chaque client ne peut louer qu'un véhicule à la fois, et un véhicule ne peut être loué que par une sule personne.
Le TP était dans un premier temps l'occasion d'utiliser l'annotation @Before dans les classes de tests, permettant de ne pas avoir à copier/coller l'initialisation de véhicules, d'une nouvelle agence... à chaque test.
Dans un deuxième temps ce TP nous permettait de commencer à utiliser l'héritage, notamment en nous faisant créer une classe Car et Motorbike, héritant de Vehicle, et de nous faire expérimenter dessus.

* Le dossier tp7 est organisé comme ceci :

  *  Un dossier src qui contient dans un paquetage rental les sources fournies (la classe Vehicle, VehicleFilter, MaxPriceFilter, BrandFilter...), les classes qu'on a complétées et créées (RentalAgency, AndFilter, Car, MotorBike, SuspiciousRentalAgency, UnknownVehicleException) et deux classes RentalAgencyMain et HeritageAgencyMain, qui définissent les deux main du TP (plus de détails ci-dessous).

  La classe RentalAgencyMain définit le main défini à la question 2 du TP. Ce main crée une agence de location y place 6 véhicules et fait beaucoup de manipulations à partir de ça. 3 filtres sont testés, trois clients louent et rendent des véhicules alors que la classe HeritageAgencyMain définit elle le main demandé aux question 6 et 8 du TP.

  On place alors dans l'agence des objets Motorbike et Car en plus des Vehicle et on crée plus loin un objet SuspiciousRentalAgency. Il n'y a ici qu'un filtre testé sur chaque échange et deux clients (un ayant moins de 25 ans et l'autre non).

  Ces deux main remplissent deux fonctions différentes, le premier sert plus à montrer les fonctions de RentalAgency en action alors que le deuxième sert plus à utiliser l'héritage, c'est pourquoi nous avons préféré les séparer plutôt que d'avoir un main dans lequel l'ensemble aurait été plus "fouilli". Pour l'éxecution de ces main avec make, on utilisera les target "jar1" et "jar2" (ou "rental1" et "rental2", voir le paragraphe Usage du Makefile).

  * Un dossier test qui contient évidemment toutes les classes de test (également dans un paquetage rental).

  * Le fichier test-1.7.jar nécessaire pour la compilation et execution des tests.
  * Le Makefile
  * Le fichier Readme.md

  * Les fichiers manifest-agency et manifest-heritage pour permettre la création des deux fichiers jar correspondant aux deux main. Le fichier manifest-agency définit la classe RentalAgencyMain comme principale alors que manifest-heritage definit HeritageAgencyMain comme principale.




## HOW TO


### récupération des données

Pour récupérer les données du projet, suivez les étapes suivantes :

* Si vous avez déjà une version locale du dépôt Git :
    * il vous suffit d'exécuter la commande shell suivante :
        ``` bash
        $ git pull
        ```
    Vous aurez ensuite accès à tous les fichiers du TP, et vous pourrez l'ouvrir dans
    un éditeur de texte.


* Si vous n'avez pas encore de version locale du dépôt :
    * Exécutez la commande suivante pour créer une version locale du dépôt dans
    le dossier *dossier-tp* :
        ```bash
        $ git clone https://gitlab-etu.fil.univ-lille1.fr/laghmich/laghmich-idtaleb-poo.git dossier-tp
        ```
        (**Attention**, le dossier doit être vide originellement)

    * Si vous préférez utiliser votre clé SSH (si elle est configurée sur votre
      [compte](https://docs.gitlab.com/ee/gitlab-basics/create-your-ssh-keys.html)) :

        ```bash
        $ git clone git@gitlab-etu.fil.univ-lille1.fr:laghmich/laghmich-idtaleb-poo.git
        ```
    Vous aurez de cette manière accès aux différents fichiers du projet. Pour mettre
     à jour ces fichiers, utilisez la commande précisée ci-dessus.

### Generation de la documentation
* Pour gener la documentation,Placez-vous dans le dossier tp7/src et passez la commande suivante :
  ```bash
  $ javadoc -d ../docs -subpackages battleship
  ```
 Pour la consulter, ouvrez le fichier index.html qui se trouve dans le dossier docs.

### Compilation des sources du projet (à faire en premier)

* Pour compiler les sources du projet, placez-vous a la racine du projet et passez les commandes suivantes :

  ```bash
  $ mkdir classes
  ```
  Ensuite, mettez vous dans le dossier src et passez la commande suivante:
    ```bash
    $ javac rental/*.java -d ../classes

    ```

### Compilation et execution des tests

* Pour compiler une classe de test, placez-vous dans le dossier tp7/
et éxécutez la commande suivante:

  ```bash
  $ javac -classpath test-1.7.jar test/NomDeLaClasseDeTest.java
  ```
  *  exemple: Pour compiler la classe RentalAgencyTest ,éxécutez la commande :

  ```bash
  $ javac -classpath test-1.7.jar test/rental/RentalAgencyTest.java
  ```
* Pour executer une classe de test, placez-vous dans le dossier tp7/
et éxécutez la commande suivante:

  ```bash
  $ java -jar test-1.7.jar NomDeLaClasseDeTest
  ```
  *  exemple: Pour executer la classe ShipTest ,éxécutez la commande :
  ```bash
  $ java -jar test-1.7.jar RentalAgencyTest
  ```

### Execution du programme avec le .jar executable

  placez-vous dans le dossier tp7/classes et ensuite, passez la commande suivante:

  ```bash
  $ jar cvfm ../rental.jar ../manifest-agency rental
  ```   
	ensuite placez vous au dossier tp7 et passez la commande suivante suivie du nombre de parties que vous voulez jouer :
  ```bash
	$ java -jar rental.jar
  ```
  vous pouvez passez les memes commande pour la partie heritage en remplacant manifest-agency par manifest-heritage

### Execution du programme sans le .jar executable
placez-vous dans le dossier tp7/classes et ensuite, passez la commande suivante:
  ```bash
  $ java -classpath classes rental.RentalAgencyMain
  ```  
ou
```bash
$ java -classpath classes rental.HeritageAgencyMain
```  

### Usage du makefile

Le Makefile se trouvant dans le répertoire TP7, il faut y accéder par la commande cd TP7 après avoir récupéré le depot distant grâce à git pull, toutes les commandes du Makefile se font dans le répertoire.

##### Compilation des sources
  Pour compiler les sources du projet, placez-vous a la racine du projet et passez las commande suivante pour compiler toutes les classes du projets :
  ```bash
  $ make compileAll
  ```  
  Pour compiler une seule classe passez la commande :
  ```bash
  $ make compile'NomDeLaClasse'
  ```  
  exemple:
  ```bash
  $ make compileRentalAgency
  ```  
##### Generation de la doc
  Pour generer la doc , passez la commande suivante:
  ```bash
  $ make doc
  ```  
Un dossier docs est alors créé dans TP7, dans ce fichier se trouvent plusieurs fichiers en .html, ouvrir le fichier index.html vous permet de consulter la doc.

##### Execution et compilation des tests
La commande suivante permet de compiler et d'executer les tests du projet:
  ```bash
  $ make testAll
  ```  
  Pour compiler et executer une seule classe de test passez la commande :
  ```bash
  $ make test'NomDeLaClasse'
  ```  
  **Attention !** La compilation des tests exige normalement que les fichiers sources soient d'abord compilés,.

##### Execution du programme avec le .jar executable

  La commande suivante permet de créer le fichier .jar executable et de l'executer:

  Pour le programme RentalAgencyMain :  
  ```bash
  $ make jar1
  ```
  Pour le programme HeritageAgencyMain :
  ```bash
  $ make jar2
  ```

##### Execution du programme sans le .jar executable

  ```bash
  $ make rental1
  ```  

  ```bash
  $ make rental2
  ```  


##### Nettoyage du TP7
La commande suivante supprime le dossier classes, le dossier docs, le fichier .jar et les fichiers .class, ces fichiers pouvant tous être recréés avec les commandes ci-dessus :
  ```bash
  $ make clean
  ```  
