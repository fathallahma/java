package rental;
import org.junit.*;
import static org.junit.Assert.*;

public class CarTest{

  private Car car1;
  private Car car2;
  
  @Before
  public void before(){
    this.car1 = new Car("Brand 1", "Model 1", 2010, 150, 4);
    this.car2 = new Car("Brand 2", "Model 2", 2012, 200, 5);
  }

  @Test
  public void testGetPassengers(){
    assertEquals(4,this.car1.getNbPassengers());
    assertEquals(5,this.car2.getNbPassengers());
  }

  @Test
	public void testEquals() {
		Car c3 = new Car("brand1","model1", 2015, 100.0f, 4);
		Car c4 = new Car("brand1","model1", 2015, 100.0f, 2);
		Car c5 = new Car("Brand 1", "Model 1", 2010, 150, 4);
		assertTrue(car1.equals(c5));
		assertFalse(car1.equals(c4));
		assertFalse(car1.equals(car2));
		assertFalse(car1.equals(c4));
		assertFalse(car1.equals(new Object()));
   }
	
  public static junit.framework.Test suite() {
    return new junit.framework.JUnit4TestAdapter(rental.CarTest.class);
  }
}
