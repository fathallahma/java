package rental;
import org.junit.*;
import static org.junit.Assert.*;

public class AndFilterTest{

  private AndFilter interFilter;
  private MaxPriceFilter priceFilter;
  private MaxPriceFilter priceFilter2;
  private BrandFilter brandFilter;

  @Before
  public void before(){
    this.interFilter = new AndFilter();
    this.priceFilter = new MaxPriceFilter(200);
    this.priceFilter2 = new MaxPriceFilter(150);
    this.brandFilter = new BrandFilter("Brand 1");
  }

  /** tests if the filters get added to the main filter*/
  @Test
  public void filtersGetAddedToTheBigFilter(){
    assertFalse(this.interFilter.getFilters().contains(this.priceFilter));
    this.interFilter.addFilter(this.priceFilter);
    assertTrue(this.interFilter.getFilters().contains(this.priceFilter));
  }
  /** tests if the filters accept the vehicles */
  @Test
  public void acceptVehiclesWhileHavingSeveralFilters(){
    Vehicle v1 = new Vehicle("Brand 1", "Model 1", 2010, 140);
    Vehicle v2 = new Vehicle("Brand 1", "Model 2", 2010, 175);
    Vehicle v3 = new Vehicle("Brand 2", "Model 3", 2010, 215);
    Vehicle v4 = new Vehicle("Brand 2", "Model 4", 2010, 150);
    
    //on ne veut que les voitures avec un prix inférieur à 200
    this.interFilter.addFilter(this.priceFilter);
    assertTrue(this.interFilter.accept(v1));
    assertTrue(this.interFilter.accept(v2));
    assertFalse(this.interFilter.accept(v3));
    assertTrue(this.interFilter.accept(v4));
    
    //on ne veut que les voitures avec un prix inférieur à 200 avec la marque "Brand 1"
    this.interFilter.addFilter(this.brandFilter);
    assertTrue(this.interFilter.accept(v1));
    assertTrue(this.interFilter.accept(v2));
    assertFalse(this.interFilter.accept(v3));
    assertFalse(this.interFilter.accept(v4));
    
    //on ne veut que les voitures avec un prix inférieur à 150 avec la marque "Brand 1"
    this.interFilter.addFilter(this.priceFilter2);
    assertTrue(this.interFilter.accept(v1));
    assertFalse(this.interFilter.accept(v2));
    assertFalse(this.interFilter.accept(v3));
    assertFalse(this.interFilter.accept(v4));
  }
  
  @Test
  public void secondMethodToTestTheAcceptFunction() {
    Vehicle v1 = new Vehicle("Brand 1","model1",2015,100);
    Vehicle v2 = new Vehicle("Brand 2","model1",2016,150);
    Vehicle v3 = new Vehicle("Brand 1","model2",2016,120);
    Vehicle v4 = new Vehicle("Brand 3","model1",2016,180);
    
    interFilter.addFilter(priceFilter2);
    interFilter.addFilter(brandFilter);
    
    assertSame(interFilter.accept(v1), priceFilter2.accept(v1) && brandFilter.accept(v1));
    assertSame(interFilter.accept(v2), priceFilter2.accept(v2) && brandFilter.accept(v2));
    assertSame(interFilter.accept(v3), priceFilter2.accept(v3) && brandFilter.accept(v3));
    assertSame(interFilter.accept(v4), priceFilter2.accept(v4) && brandFilter.accept(v4));
   }
  
  public static junit.framework.Test suite() {
    return new junit.framework.JUnit4TestAdapter(rental.AndFilterTest.class);
  }
}

