package rental;

/** A class of a car*/
public class Car extends Vehicle {

	/**the number of passengers*/
	private int nbPassengers;
	
	/** Creates a car with a brand, a model, production year, a daily rental price and a number of passengers
	 * @param brand the car's brand
	 * @param model the car's model
	 * @param productionYear the production year of the car
	 * @param dailyRentalPrice the daily rental price
	 * @param nbPassengers the number of passengers
	 */
	public Car(String brand, String model, int productionYear, float dailyRentalPrice, int nbPassengers) {
		super(brand, model, productionYear, dailyRentalPrice);
		this.nbPassengers=nbPassengers;
	}
	
	/** returns the number of the passengers
	 * @return the number of the passengers
	 */
	public int getNbPassengers() {
		return nbPassengers;
	}

	/** returns a sentence describing the car
	 * @return a sentence describing the car*/	
	public String toString() {
		return super.toString()+"number of passengers : "+ this.nbPassengers;
	}

    
    /**
  	 * this car is equals to another if they have same brand, model,
  	 * production year, daily rental price and number of passengers.
  	 *
  	 * @see java.lang.Object#equals(java.lang.Object)
  	 */
    public boolean equals(Object o){
      return super.equals(o) && this.nbPassengers==((Car)o).nbPassengers;
    }
	
	
}
