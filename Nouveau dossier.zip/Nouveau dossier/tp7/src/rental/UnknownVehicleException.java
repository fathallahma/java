package rental;

public class UnknownVehicleException extends Exception {
	public UnknownVehicleException() {
		super( );
		}
}
