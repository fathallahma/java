package rental;

/** A class of a motor bike*/
public class Motorbike extends Vehicle {

	/**the cylinder of the motor bike*/
	private float cylinder;
	/** Creates a motor bike with a brand, a model, production year, a daily rental price and a number of passengers
	 * @param brand the car's brand
	 * @param model the car's model
	 * @param productionYear the production year of the car
	 * @param dailyRentalPrice the daily rental price
	 * @param cylinder the cylinder of the motor bike
	 */
	
	public Motorbike(String brand, String model, int productionYear, float dailyRentalPrice, float cylinder) {
		super(brand, model, productionYear, dailyRentalPrice);
		this.cylinder=cylinder;
	}
	/** returns the cylinder of the motor bike
	 * @return the cylinder motor bike
	 */
	public float getCylinder() {
		return cylinder;
	}

	/** returns a sentence describing the Motor bike
	 * @return a sentence describing the Motor bike*/	
	public String toString() {
		return super.toString()+"cylinder : "+ this.cylinder;
	}


	
	
}
