package battleship;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import battleship.Answer;
import battleship.Cell;
import battleship.Ship;

public class CellTest {

	// tests if the ship really get sunk after we shoot it
	@Test
	public void testShootWhenShipHasBeenSunked() {
		Ship ship=new Ship(0);
		Cell cell = new Cell();
		cell.setShip(ship);
		cell.shoot();
		assertEquals(Answer.SUNK,cell.shoot());

	}
	
	// test if the ship get hit and the shot decreases its life points
	@Test
	public void firstShotDecreasesLifePoints() {
		Cell c=new Cell();
		Ship ship=new Ship(3);
		c.setShip(ship);
		assertEquals(c.shoot(),Answer.HIT);
		assertEquals(c.getShip().getLifePoints(),2);
	}

	// tests if the boat get shot
	@Test
	public void hasBeenShot() {
		Cell c = new Cell();
		assertFalse(c.hasBeenShot());
		c.shoot();
		assertTrue(c.hasBeenShot());
	}
	
}
	
