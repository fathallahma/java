package battleship;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import battleship.Ship;

public class ShipTest {

	//tests if hit decreases lifePoints
	@Test
	public void testHitDecreasesLifePoints() {
		Ship ship = new Ship(3);
		assertEquals(3, ship.getLifePoints());
		ship.hitted();
		assertEquals(2, ship.getLifePoints());
	}
}
