package battleship;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import battleship.util.Position;

public class SeaTest {

	// tests if the position is not out of bounds
	@Test
	public void testPositionNotOutOfBounds1() {
		Sea sea = new Sea(10,10);
		Position p = new Position(1,2);
		assertTrue(sea.positionNotOutOfBound(p));
	}
	
	//tests if the position is  out of bounds
	@Test(expected=ArrayIndexOutOfBoundsException.class)
	public void testPositionOutOfBounds2() {
		Sea sea = new Sea(10,10);
		Position p = new Position(1,11);
		sea.positionNotOutOfBound(p);
	}
	
	//tests if shoot decreases the total life points
	@Test
	public void testShootDecreasesTotalLifePoints() {
		Sea sea = new Sea(10,10);
		Ship ship = new Ship(3);
		Position p = new Position(1,2);
		sea.addShip(ship, p , true);
		assertEquals(3,sea.getTotalLifePoints());
		sea.shoot(p);
		assertEquals(2,sea.getTotalLifePoints());
	}
	
	// tests if shoot throws the exception when the position to shoot is out of bounds
	@Test(expected=ArrayIndexOutOfBoundsException.class)
	public void testShootThrowsException() {
		Sea sea = new Sea(10,10);
		Position p = new Position(1,12);
		sea.shoot(p);
	}
}
