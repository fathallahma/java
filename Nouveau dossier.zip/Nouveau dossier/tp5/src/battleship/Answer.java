package battleship;

/**
 * AN ENUM CLASS, TO ENUMERATE ALL THE POSSIBLE ANSWERS
 */
public enum Answer {
	MISSED,
	HIT,
	SUNK;	
}
