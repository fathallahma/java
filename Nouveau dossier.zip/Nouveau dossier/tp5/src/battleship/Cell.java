package battleship;

import battleship.Ship;

/**
 * a class that represents a cell of a board.
 */
public class Cell {
	private boolean hit;
	private Ship ship;

	/**
	 * creation of a cell
	 * a cell can take a ship or not.
	 */
	public Cell() {
		this.hit = false;
		this.ship = null;
	}
	
	/**
	 * 
	 * @return true if the cell is empty
	 *         False if not.
	 */
	public boolean isEmpty() {
		return this.ship == null;
	}
	
	/**
	 * @return the right answer if a cell is hit
	 */
	public Answer shoot() {
		if(this.ship != null && this.ship.hasBeenSunked()) {
			return Answer.SUNK;
		}
		if(this.ship == null) {
			this.hit = true;
			return Answer.MISSED;
		}
		else {
			if(!(hasBeenShot())){
				this.hit = true;
				this.ship.hitted();
				return Answer.HIT;
			}
			else {
				System.out.println("   * Ooops! The ship was hit... The ship cannot be hit for twice in the same time *");
				return Answer.MISSED;
			}
		}
	}

	/**
	 * @return true if the cell is hit,
	 *         false otherwise.
	 */
	public boolean hasBeenShot() {
		return this.hit;
	}

	/**
	 * @return the ship
	 */
	public Ship getShip() {
		return ship;
	}

	/**
	 * @param ship the ship to set
	 */
	public void setShip(Ship ship) {
		this.ship = ship;
	}
    
	/**
	 * a string representation of the cell
	 * @param defender the defender user's
	 * @return the string representation of the cell in the board
	 */
	public char getCharacter(boolean defender) {
		char res = ' ';
		if(defender) {
			if(this.isEmpty()) {
				res = '~';
			}
			else {
				if(!(hasBeenShot())) {
					res = 'B';
				}
				else{
					res = '*';
				}			
			}
		}
		
		else {
			if(!hasBeenShot() ) {
				res = '.';
			}
			else{
				res = '~';
			}
			if(!this.isEmpty() && this.hit){
				res = '*';
			}
		}
		return res;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (hit ? 1231 : 1237);
		result = prime * result + ((ship == null) ? 0 : ship.hashCode());
		return result;
	}
	
	

}
