package battleship;
import battleship.util.Position;

/**
 * a class to represent the whole board 
 * */
public class Sea {
	private Cell[][] cells;
	private int width;
	private int heigth;
	private int totalLifePoints;
	
	/**
	 * creation of the sea, from a cell
	 * @param width the width of the board(sea)
	 * @param heigth the height of the board(sea)
	 */
	public Sea(int width, int heigth) {
		this.cells = new Cell[heigth][width];
		this.width = width;
		this.heigth = heigth;
		this.totalLifePoints = 0;
		for(int l = 0; l < this.heigth; l++) {
			for(int c = 0; c < this.width; c++) {
				this.cells[l][c] = new Cell();
			}
		}
	}

	/**
	 * @return the cells
	 */
	public Cell[][] getCells() {
		return cells;
	}

	/**
	 * @return the width of the sea
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * @return the totalLifePoints of all the ships
	 */
	public int getTotalLifePoints() {
		return totalLifePoints;
	}

	/**
	 * @return the height of the sea
	 */
	public int getHeigth() {
		return heigth;
	}
	
	/**
	 * test if the position of the cell is out of bounds
	 * @param pos the position of the cell
	 * @return true if the position of the cell is not out of bounds
	 * @throws ArrayIndexOutOfBoundsException if position is out of bounds
	 */	
	public boolean positionNotOutOfBound(Position pos) throws ArrayIndexOutOfBoundsException{
		if(pos.getX()>this.width || pos.getY()>this.heigth) {
			throw new ArrayIndexOutOfBoundsException("you are outside of the board");
		}
		else {
			return true;
		}
	}
	
	/**
	 * shoot in the cell given by its position
	 * @param pos the position of the cell to be hit
	 * @return the  answer when the attacker hits the box represented by the position
	 * @throw ArrayIndexOutOfBoundsException if position is out of bounds
	 */
	public Answer shoot(Position pos) throws ArrayIndexOutOfBoundsException{
		Answer answer = this.cells[pos.getX()][pos.getY()].shoot();
		System.out.println("\n\t\t* After hit: ----> " + answer + " <----");
		if(positionNotOutOfBound(pos) == true) {
			if (answer == Answer.HIT || answer == Answer.SUNK ) {
				this.totalLifePoints--;
			}
			return answer;
		}
		else{
			throw new ArrayIndexOutOfBoundsException();
		}
	}
	
	/** displays the board line by line and cell by cell,
	* the display changes for the defender or the opponent, defined
	* by the <code>defender</code> argument
	* @param defender <code>true</code> if display is for defender,
	* 				  <code>false</code> if for opponent
	*/
	public void display(boolean defender) {
		String ch = "\t\t\t  ";
		for (int l = 0; l < heigth; l++) {		
			for (int c = 0; c < width; c++) {			
				ch = ch + this.cells[l][c].getCharacter(defender);			
			}
			System.out.println(ch);
			ch = "\t\t\t  ";
		}
	}
	
	/** add the ship b vertically down from position p.  The number of
	 *  cells is determined by the ship length.
	 * @param shipToPlace the ship to add
	 * @param position the position of the first (top) cell occupied by the ship
	 * @throws IllegalStateException if the ship b can not be placed on the sea
	 *         (outside of the board or some cell is not empty)
	 */
	public void addShip(Ship shipToPlace, Position position, boolean vertically)throws IllegalStateException, ArrayIndexOutOfBoundsException{
		int cmp = 0;
		try {
			if(vertically) {
				for(int i = 0; i < shipToPlace.getLifePoints(); i++) {
					Cell cell = cells[position.getX()+i][position.getY()];
					try {
						if(cell.isEmpty() && positionNotOutOfBound(position)) {
							cell.setShip(shipToPlace);
						}
					}	
					catch(IllegalStateException e){
						System.out.println("Some of cells are occuped by an other ship");
					}
				}	
				this.totalLifePoints += shipToPlace.getLifePoints();
			}
			else {
				try {
					
					for(int i = 0; i < shipToPlace.getLifePoints(); i++) {
						Cell cell = cells[position.getX()][position.getY()+i];
						if(cell.isEmpty() && positionNotOutOfBound(position)) {	
							cell.setShip(shipToPlace);
							cmp++;
						}
						
					// Ce code correpond à une amélioration, l'idée est dès qu'on trouve deux bateaux superposé (qui se touche au momont de l'emplacement), alors on supprime le derniers bateaux ajouté
					// et on retire ses points de vies du nombre total des lifepoints.
					// Ce code nécessite une amélioration, (fonctionne dans un certains cas)	
						else if(!cell.isEmpty() && i<cell.getShip().getLifePoints()) {
							cmp++;
						}
						else {
							for(int j = 0; j < cmp; j++) {
								Cell cellDelete = cells[position.getX()][position.getY()+j];
							    cellDelete.setShip(null); 
							}
							//throw new IllegalStateException();
						}
					// Fin du code de l'amélioration ***********************************************************************************************************************************************************************************
					}
					
					this.totalLifePoints += shipToPlace.getLifePoints();
				}	
				catch(ArrayIndexOutOfBoundsException e){
					for(int j = 0; j < cmp; j++) {
						Cell cellDelete = cells[position.getX()][position.getY()+j];
					    cellDelete.setShip(null); 
					}
					System.out.println("\t\t\t      _");
					System.out.println("\t\t\t     / \\");
					System.out.println("\t\t\t    / | \\");
					System.out.println("\t\t\t   /  !  \\");
					System.out.println("\t\t\t  =========");
					System.out.println("\t\t\t     | |");
					System.out.println("\t\t\t     | |");
					System.out.println("\t\t\t     ===");
					System.out.println("   \t\t  _   _   _   _   _   _   _  \n" + 
							           "  \t\t / \\ / \\ / \\ / \\ / \\ / \\ / \\ \n" + 
							           " \t\t( W | A | R | N | I | N | G )\n" + 
							           " \t\t \\_/ \\_/ \\_/ \\_/ \\_/ \\_/ \\_/");
					System.out.println(" * * * * Some of cells are occuped by an other ship * * * *" );
					System.out.println(" * * * The Ship cannot be placed, and it will be DELETED! * * *\n" );
				}
				
			}		
		}
		catch (IllegalStateException|ArrayIndexOutOfBoundsException e){
			System.out.println("---- outside of the board or some cell is not empty ----");
		}	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
