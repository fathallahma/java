package battleship;

/**
 * A class for a ship
 */
public class Ship {
	private int lifePoints;
    
	/**
	 * the creation of a ship
	 * @param lifePoints the life point of the ship
	 */
	public Ship(int lifePoints) {
		this.lifePoints = lifePoints;
	}
	
	/**
	 * if the ship is hit, then the point number of the ship is decreased.
	 */
	public void hitted() {
		if(this.lifePoints > 0)
			this.lifePoints--;
		else
			this.lifePoints = 0;
	}
	
	/**
	 * 
	 * @return true if the ship was sunked, 
	 *         False otherwise
	 */
	public boolean hasBeenSunked() {
		return this.lifePoints == 0;	
	}
	
	/**
	 * 
	 * @return the life points of the ship
	 */
	public int getLifePoints() {
		return lifePoints;	
	}

	/**
	 * @param lifePoints the lifePoints to set
	 */
	public void setLifePoints(int lifePoints) {
		this.lifePoints = lifePoints;
	}
	

}
