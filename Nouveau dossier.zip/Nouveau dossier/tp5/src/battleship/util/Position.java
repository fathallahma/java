package battleship.util;

/**
 * a class to represent a position in a board
 */
public class Position {
	private int x;
	private int y;

	public Position(int x, int y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * @return the x position of the cell
	 */
	public int getX() {
		return x;
	}

	/**
	 * @return the y position of the cell
	 */
	public int getY() {
		return y;
	}

	
	/**
	 * a string representation of the position
	 */
	public String toString() {
		return "(" + x + ", " + y + ")";
	}
	
	/**
	 * @param obj the comparison object
	 * @return true if two position are equal
	 *         true if the object is an instance of the Position class, and if they are equal
	 *         false, if the object is not instance of Position class
	 *         false, if the two positions are not the same 
	 */
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Position))
			return false;
		Position other = (Position) obj;
		if (x != other.x)
			return false;
		if (y != other.y)
			return false;
		return true;
	}


}
