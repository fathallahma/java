package battleship;

import java.io.IOException;
import io.Input;
import battleship.util.Position;

/** a class for the game
*/ 
public class Game {
	private Sea sea;
    
    /**
     * Creation of a game with a sea
     * @param sea the game board
     */
	public Game(Sea sea) {
		this.sea = sea;
	}
	
	/**
	 * hit the cell chosen by the attacker, and display the sea after he hit that cell
	 */
	public void attack(){
		try {
			System.out.println("\n--> Which cell do you want to hit? (You must enter a value that corresponds to the row \n    of the cell, then a value for its colomn.)\n");
			int getXCoordinate;
			int getYCoordinate;
			try {
				System.out.println("1- Enter the appropriate row of the Cell:");
				getXCoordinate = Input.readInt();
				System.out.println("2- Enter the appropriate colomn of the Cell:");
				getYCoordinate = Input.readInt();
				Position pos = new Position(getXCoordinate, getYCoordinate);
				this.sea.shoot(pos);
			} 
			catch (IOException e) {
				getXCoordinate = 0;
				getYCoordinate = 0;
				System.out.println("* Sorry! the value must be an integer!");
			}
				
			
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("\n  *************** WARNING ****************");
			System.out.println("* Sorry, but you are outside of the board!");	
			System.out.println("* The selected cell is not taken. \n* Please choose another cell!\n");
		}
	}
	
	/**
	 * playing the game
	 */
	public void play(){
		boolean isDefender = false; // changez la valeur à true, pour être en mode déffenseur.
		while(this.sea.getTotalLifePoints() != 0) {
			int totalLifePoints = this.sea.getTotalLifePoints();
			System.out.println("\t      * Total Life Points of the ships: " + totalLifePoints + "\n");
			this.sea.display(isDefender); 
			System.out.println("\n**************************************************************************************\n");
			attack();
	    }
		System.out.println("\t____ ____ _  _ ____ ____ ____ ___ _  _ _    ____ _ ____ _  _ \n" + 
						   "\t|    |  | |\\ | | __ |__/ |__|  |  |  | |    |__| | |  | |\\ | \n" + 
				           "\t|___ |__| | \\| |__] |  \\ |  |  |  |__| |___ |  | | |__| | \\| ");
		System.out.println("\t\t\t_ _ ____ _  _   _  _ _ __ _  \n" + 
				           " \t\t\t Y  [__] |__|   |/\\| | | \\|  ");	
		System.out.println("\t\t\t\t  \\\n" + 
						   "\t\t\t\t   \\\n" + 
						   "\t\t\t\t      .--.\n" + 
						   "\t\t\t\t     |o_o |\n" + 
						   "\t\t\t\t     |:_/ |\n" + 
						   "\t\t\t\t    //   \\ \\\n" + 
						   "\t\t\t\t   (|     | )\n" + 
						   "\t\t\t\t  /'\\_   _/`\\\n" + 
						   "\t\t\t\t  \\___)=(___/");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
