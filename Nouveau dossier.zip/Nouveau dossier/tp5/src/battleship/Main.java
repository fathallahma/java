package battleship;
import battleship.util.Position;
import battleship.Ship;

public class Main {

	public static void main(String[] arg){
		System.out.println("\n*************************** ****************************** ***************************");
		System.out.println("*************************** WELCOME TO THE BATTLESHIP GAME ***************************");
		System.out.println("*************************** ****************************** ***************************");
		System.out.println("\n**************************** This is the Sea *****************************************");
		System.out.println("                            -----------------\n");
		
		/** Creation of the sea */
		Sea sea = new Sea(10, 10);
		
		/** The positions of the ships */
		Position position1 = new Position(1, 3);
		Position position2 = new Position(7, 2);
		Position position3 = new Position(9, 3);
		
		/** Add two ships to the sea */
		sea.addShip(new Ship(3), position1, true); // "true" correspond à mettre le bateau verticalement
		sea.addShip(new Ship(6), position2, false); 
		sea.addShip(new Ship(4), position3, false);
		
		/** Creation of the game */
		Game game = new Game(sea);
		
		/** Playing the game*/
		game.play();
	}
}
