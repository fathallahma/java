# TP 5

## Auteurs

 -Manal Laghmich
 -Reda Id idtaleb

 groupe : 6

## Introduction

Dans ce TP, nous avons modélisé le jeu de la bataille navale. La bataille navale, appelée aussi touché-coulé, est un jeu de société dans lequel deux joueurs doivent placer des « navires » sur une grille tenue secrète et tenter de « toucher » les navires adverses. Le gagnant est celui qui parvient à couler tous les navires de l'adversaire avant que tous les siens ne le soient. On dit qu'un navire est coulé si chacune de ses cases a été touchées par un coup de l'adversaire.

Dans ce TP, nous nous sommes servis d'un Makefile qui permettra de faciliter l'exécution de commandes.

On utilisera deux packages io qui nous est fourni et battleship.

Dans le package battleship, nous avons plusieurs classes:

Ship qui permet de créer les bateaux en initialisant sa longueur, on rappellera que son nombre de points de vie à l'initialisation est le même que sa longueur. On pourra également tiré sur les bateaux avec la méthode hit() ou vérifier si le bateau est coulé.

Cell qui crée une cellule. Cette cellule pourra être vide ou contenir un bateau. On pourra tirer sur cette cellule afin de viser un bateau.

Sea est une mer initialisée par sa longueur et sa largeur. Elle possède longueur * largeur cellules. On y dépose des bateaux, on peut donc calculer le nombre total de points du joueur.

Answer est de type Enum et permet de donner la réponse après qu'un joueur est joué avec 3 réponses possibles, MISSED si le bateau n'est pas touché, HIT s'il est touché, SUNK s'il est touché et coulé c'est-à-dire que son nombre de points de vie est à 0.

Game permet à l'aide du package io de créer une partie.

Main permet de totalement simulé une partie, on initialise alors la taille de Sea, le nombre de bateaux avec leurs tailles et placements.

et un subpackage util dans lequel se trouve la classe Position qui prend en paramètre des coordonnées x et y.



## HOW TO


### récupération des données

Pour récupérer les données du projet, suivez les étapes suivantes :

* Si vous avez déjà une version locale du dépôt Git :
    * il vous suffit d'exécuter la commande shell suivante :
        ``` bash
        $ git pull
        ```
    Vous aurez ensuite accès à tous les fichiers du TP, et vous pourrez l'ouvrir dans
    un éditeur de texte.


* Si vous n'avez pas encore de version locale du dépôt :
    * Exécutez la commande suivante pour créer une version locale du dépôt dans
    le dossier *dossier-tp* :
        ```bash
        $ git clone https://gitlab-etu.fil.univ-lille1.fr/laghmich/laghmich-idtaleb-poo.git dossier-tp
        ```
        (**Attention**, le dossier doit être vide originellement)

    * Si vous préférez utiliser votre clé SSH (si elle est configurée sur votre
      [compte](https://docs.gitlab.com/ee/gitlab-basics/create-your-ssh-keys.html)) :

        ```bash
        $ git clone git@gitlab-etu.fil.univ-lille1.fr:laghmich/laghmich-idtaleb-poo.git
        ```
    Vous aurez de cette manière accès aux différents fichiers du projet. Pour mettre
     à jour ces fichiers, utilisez la commande précisée ci-dessus.

### Generation de la documentation
* Pour gener la documentation,Placez-vous dans le dossier tp5/src et passez la commande suivante :
  ```bash
  $ javadoc -d ../docs -subpackages battleship
  ```
 Pour la consulter, ouvrez le fichier index.html qui se trouve dans le dossier docs.

### Compilation des sources du projet (à faire en premier)

* Pour compiler les sources du projet, placez-vous a la racine du projet et passez les commandes suivantes :

  ```bash
  $ mkdir classes
  ```
  Ensuite, mettez vous dans le dossier src et passez la commande suivante:
    ```bash
    $ javac battleship/*.java -d ../classes

    ```

### Compilation et execution des tests

* Pour compiler une classe de test, placez-vous dans le dossier tp5/
et éxécutez la commande suivante:

  ```bash
  $ javac -classpath test-1.7.jar test/NomDeLaClasseDeTest.java
  ```
  *  exemple: Pour compiler la classe ShipTest ,éxécutez la commande :

  ```bash
  $ javac -classpath test-1.7.jar test/battleship/ShipTest.java
  ```
* Pour executer une classe de test, placez-vous dans le dossier tp5/
et éxécutez la commande suivante:

  ```bash
  $ java -jar test-1.7.jar NomDeLaClasseDeTest
  ```
  *  exemple: Pour executer la classe ShipTest ,éxécutez la commande :
  ```bash
  $ java -jar test-1.7.jar ShipTest
  ```

### Execution du programme avec le .jar executable

  placez-vous dans le dossier tp5/classes et ensuite, passez la commande suivante:

  ```bash
  $ jar cvfm ../battleship.jar ../manifest-bs battleship
  ```   
### Execution du programme sans le .jar executable

  ```bash
  $ java -classpath classes battleship.Main
  ```  


### Usage du makefile

Le Makefile se trouvant dans le répertoire TP5, il faut y accéder par la commande cd TP5 après avoir récupéré le depot distant grâce à git pull, toutes les commandes du Makefile se font dans le répertoire.

##### Compilation des sources
  Pour compiler les sources du projet, placez-vous a la racine du projet et passez las commande suivante pour compiler toutes les classes du projets :
  ```bash
  $ make compileAll
  ```  
  Pour compiler une seule classe passez la commande :
  ```bash
  $ make compile'NomDeLaClasse'
  ```  
  exemple:
  ```bash
  $ make compileShip
  ```  
##### Generation de la doc
  Pour generer la doc , passez la commande suivante:
  ```bash
  $ make doc
  ```  
Un dossier docs est alors créé dans TP5, dans ce fichier se trouvent plusieurs fichiers en .html, ouvrir le fichier index.html vous permet de consulter la doc.

##### Execution et compilation des tests
La commande suivante permet de compiler et d'executer les tests du projet:
  ```bash
  $ make allTests
  ```  
  Pour compiler et executer une seule classe de test passez la commande :
  ```bash
  $ make test'NomDeLaClasse'
  ```  
  **Attention !** La compilation des tests exige normalement que les fichiers sources soient d'abord compilés,.

##### Execution du programme avec le .jar executable

  La commande suivante permet de créer le fichier example.jar executable et de l'executer:
  ```bash
  $ make archive
  ```

##### Execution du programme sans le .jar executable

  ```bash
  $ make battleship
  ```  

##### Nettoyage du TP5
La commande suivante supprime le dossier classes, le dossier docs, le fichier .jar et les fichiers .class, ces fichiers pouvant tous être recréés avec les commandes ci-dessus :
  ```bash
  $ make clean
  ```  
