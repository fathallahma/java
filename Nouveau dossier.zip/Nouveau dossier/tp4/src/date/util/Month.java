package date.util;

/** A class that enumerates months*/
public enum Month {

	January(31),
	February(28),
	March(31),
	April(30),
	May(31),
	June(30),
	July(31),
	August(31),
	September(30),
	October(31),
	November(30),
	December(31);
	
	/** the number of days of the month*/
	private int nbDays;
	
	/** creates a month with a number of days
	 * @param n the number of days of the month
	 */
	private Month(int n) {
		this.nbDays = n;
	}
	
	/** returns the month's number of days
	 * @param year the year of the dates
	 * @return the number of days of the month
	 */
	public int getNbOfDays(int year) {
		if (this != Month.February) {
			return this.nbDays;
		}
		else if(isLeapYear(year)) {
			return this.nbDays + 1;
		}
		else {
			return this.nbDays;
		}
		
	}
	
	/** returns if the year is leap or not
	 * @param year the year of the dates
	 * @return true if the year is leap, false if not
	 */
	public static boolean isLeapYear(int year){
		return ((year%4==0) && (year%100!=0)) || ((year%400)==0);
	}

	/**
	 * 
	 * @return the next month
	 */
	public Month next() {
		int ordre = this.ordinal();
		return Month.values()[(ordre + 1)%Month.values().length];
	}
}

	
	