package date;

import date.util.Month;

/** A Main class for Date*/
public class DateMain {

	public static void main(String[] args) {
		Date date1 = new Date(10, Month.February, 2020);
		Date date2 = new Date(27, Month.February, 2020);
		Date date3 = new Date(29, Month.February, 2020);
		Date date4 = new Date(31, Month.December, 2020);
		
		System.out.println("\n ********* ********* This is a program to launch the Date class ********* *********");
		System.out.println("\n-> Date1" + date1.toString());
		
		System.out.println("\n* The day of date1: " + date1.getDay());
		System.out.println("* The month of date1: " + date1.getMonth());
		System.out.println("* The year of date1: " + date1.getYear());
		
		System.out.println("\n\n\t\t   ** The tomorrow's date **");
		System.out.println("\n-> Date1" + date1);
		System.out.println("-> Date3" + date3);
		System.out.println("-> Date4" + date4);
		Date date1Tomorrow = date1.tomorrow();	
		Date date3Tomorrow = date3.tomorrow();	
		Date date4Tomorrow = date4.tomorrow();
		System.out.println("\n* The day after tomorrow's date1" + date1Tomorrow.toString());
		System.out.println("* The day after tomorrow's date3" + date3Tomorrow.toString());
		System.out.println("* The day after tomorrow's date4" + date4Tomorrow.toString());
		
		System.out.println("\n\n\t\t   ** The number of days between two Dates **");
		int nbOfDaysBetweenDate = date1.nbOfDaysBetweenDate(date2);
		System.out.println("\n-> Date1" + date1.toString());
		System.out.println("-> Date2" + date2.toString());
		System.out.println("\n* The number of days between date1 and date2 is: " + nbOfDaysBetweenDate + " days.");
	    
		System.out.println("\n\n\t\t   ** The equality test between two Dates **");
		System.out.println("\n-> Date1" + date1.toString());
		System.out.println("-> Date2" + date2.toString());
		//cette boucle permet d'exécuter la méthode equal() sur deux cas(le cas différence, le cas d'égalité)
		int i = 0;
		while(i < 2) {
			boolean areEqual = date1.equals(date2);
			if (areEqual==false) {
				System.out.println("\n* date1 is not equal to date2");
				date2 = new Date(10, Month.February, 2020);
				System.out.println("\n-> Date2 become " + date2.toString() + " (like Date1)");
			}	
			else
				System.out.println("\n* date1 is equal to date2");
			i++;
		}
		
		System.out.println("\n\n\t\t   ** The date after a number of days **");
		System.out.println("\n-> Date1" + date1.toString());
		int nbOfDays1 = 5;
		System.out.println("\n* Date1 after " + nbOfDays1 + "   days, will be: " + date1.dateAfterNbDay(nbOfDays1));
        int nbOfDays2 = 20;
        System.out.println("* Date1 after " + nbOfDays2 + "  days, will be: " + date1.dateAfterNbDay(nbOfDays2));
        int nbOfDays3 = 330;
        System.out.println("* Date1 after " + nbOfDays3 + " days, will be: " + date1.dateAfterNbDay(nbOfDays3));
	}

}
