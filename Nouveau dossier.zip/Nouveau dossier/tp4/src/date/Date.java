package date;
import date.util.Month;

/**
 * a class to represent a Date
 */
public class Date{
	
  /** the day*/
  int day;
  /** the month*/
  Month month;
  /** the year*/
  int year;
  
	 /** creates a date with a day, a month and a year
	  * @param day the day of the date
	  * @param month the month of the date
	  * @param year the year of the date
	  */
	public Date(int day, Month month, int year){
	   this.day=day;
	   this.month=month;
	   this.year=year;
	}
	
	/** returns the current day
	 * @return the day of the date
	 */
	public int getDay() {
		return day;
	}
	
	/** sets the current day
	 * @param day the day to be set
	 */
	public void setDay(int day) {
		this.day = day;
	}
	
	/** returns the current month
	 * @return the month of the date
	 */
	public Month getMonth() {
		return month;
	}
	
	/** sets the current month
	 * @param month the month the be set
	 */
	public void setMonth(Month month) {
		this.month = month;
	}
	
	/** returns the current year
	 * @return the year
	 */
	public int getYear() {
		return year;
	}
	
	/** sets the current year
	 * @param year the year of the date
	 */
	public void setYear(int year) {
		this.year = year;
	}
	
	/** returns the date of tomorrow
	 * @return the date of tomorrow
	 */
	public Date tomorrow() {
		if(getDay() < this.month.getNbOfDays(getYear())) {
			return new Date(this.day+1, this.month, this.year);
		}
		else {
			if(this.month != Month.December){
				return new Date(1, this.month.next(), this.year);
			}
			else {
				return new Date(1, Month.January, this.year+1);
			}	
		}
	}
	
	/**
	 * comparison between two dates
	 * @param d the comparing date 
	 * @return the difference between two date
	 */
	public int compareTo(Date d) {
		if(d.year >= this.year) {
			if(d.month == this.month) {
				return this.day - d.day;
			}
			else {
				return this.month.ordinal()-d.month.ordinal();
			}
		}
		else {
			return this.year-d.year;
		}
	}
	
	/**
	 * calculate the number of days between two dates
	 * @param d the date for which we want to know the number of days, starting from the current date.
	 * @return the number of days between two dates
	 */
	public int nbOfDaysBetweenDate(Date d) {
		Date first, second;
		if(this.compareTo(d) < 0) {
			first = this;
			second = d;
		}
		else {
			first = d;
			second = this;
		}
		int res = 0;
		while(first.compareTo(second) != 0) {
			first = first.tomorrow();
			res++;
		}
		return res;
	}

	/**
	 * compare if two objects are equivalent, 
	 * and if they are of the same type.
	 * @param obj the object that we want to compare with.
	 * @return true, if the object is equal to the current date
	 *         false, otherwise 
	 */
	public boolean equals(Object obj) {
		if(obj instanceof Date) {
			Date d = (Date) obj;
			return this.compareTo(d) == 0;
		}
		else {
			return false;
		}
	}
	
	/**
	 * calculate what date will be after a defined number of days.
	 * @param n a number representing the number of days
	 * @return a date after a certain number of days
	 * @throws IllegalArgumentException
	 */
	public Date dateAfterNbDay(int n) throws IllegalArgumentException{
		if(n < 0) {
			throw new IllegalArgumentException();
		}
		else {
			Date d = this;
			while(n > 0) {
				d = d.tomorrow();
				n--;
			}
			return d;
		}		
	}

	/**
	 * a string representation of the date
	 * @return return a string representation of the date
	 */
	public String toString() {
		return "(d/m/y): " + day + "/ " + month + "/ " + year;
	}
	
	

}
