package date;

import org.junit.*;
import date.Date;
import date.util.Month;
import static org.junit.Assert.*;

/**
 *A Test Class for Date
*/
public class DateTest {
	
	private Date d1;
	private Date d2;
	private Date d3;
	private Date d4;
	
	/**
	 * initialization of the instances
	 */
	@Before
	public void initialization() {
		d1 = new Date(27, Month.February, 2020);
		d2 = new Date(31, Month.October, 2020);
		d3 = new Date(31, Month.December, 2019);
		d4 = new Date(20, Month.December, 2019);
	}
    
	/**
	 * test if the day number is correct, when creating the date.
	 */
	@Test
	public void testGetDay() {
		assertEquals(d1.getDay(), 27);	
	}
	
	/**
	 * test if the month is correct, when creating the date.
	 */
	@Test 
	public void testGetMonth() {
		assertEquals(d1.getMonth(), Month.February);
	}
	
	/**
	 * test if the year number is correct, when creating the date.
	 */
	@Test
	public void testGetYear() {
		assertEquals(d1.getYear(), 2020);
	}
	/**
	 * test of the special case, when the day of the date is not the last day of the month.
	 */
	@Test
	public void testTomorrowDayCase() {
		assertEquals(d1.tomorrow().getDay(), 28);
		assertEquals(d1.tomorrow().getMonth(), Month.February);
		assertEquals(d1.tomorrow().getYear(), 2020);
	}
	
	/**
	 * test of the special case, when the day of the date is the last day of the month, and when the month is not December.
	 */
	@Test
	public void testTomorrowMonthCase() {
		assertEquals(d2.tomorrow().getDay(), 1);
		assertEquals(d2.tomorrow().getMonth(), Month.November);
		assertEquals(d2.tomorrow().getYear(), 2020);
	}
	
	/**
	 * special case test, when the date day is the last day of the month, and when the month is December.
	 */
	@Test
	public void testTomorrowYearCase() {
		assertEquals(d3.tomorrow().getDay(), 1);
		assertEquals(d3.tomorrow().getMonth(), Month.January);
		assertEquals(d3.tomorrow().getYear(), 2020);
	}
	
	/**
	 * we test the difference between two dates. 
	 * In this case we test the difference at day level.
	 */
	@Test
	public void testCompareTo() {
		Date date = new Date(29, Month.October, 2020);
		int comp = d2.compareTo(date);
		assertEquals(comp, 2);
	}
	
	/**
	 * we test the difference between two dates. 
	 * In this case we test the difference at month level.
	 */
	@Test
	public void testCompareToCase2() {
		Date date = new Date(1, Month.November, 2020);
		int comp = date.compareTo(d2);
		assertEquals(comp, 1);
	}
	
	/**
	 * we test the difference between two dates. 
	 * In this case we test the difference at year level.
	 */
	@Test
	public void testCompareToCase3() {
		Date date = new Date(27, Month.February, 2021);
		int comp = date.compareTo(d1);
		assertEquals(comp, 1);
	}
	
	/**
	 * we test the number of days between two different dates
	 */
	@Test
	public void testnbOfDaysBetweenDate() {
		int numberOfDaysBetweenTwoDates = d3.nbOfDaysBetweenDate(d4);
		assertEquals(numberOfDaysBetweenTwoDates, 11);
	}
	
	/**
	 * test if two dates are equals. 
	 * testing two equal dates
	 */
	@Test
	public void testequalstoTrueCase() {
		Date sameObject = new Date(27, Month.February, 2020);
		assertTrue( d1.equals(d1) );
		assertTrue( d1.equals(sameObject) );	
	}
	
	/**
	 * test if two dates are equals. 
	 * testing two different dates
	 */
	@Test
	public void testequalstoFalseCase() {
		Date notSameObject = new Date(28, Month.February, 2020);
		assertFalse( d1.equals(notSameObject) );	
	}
	
	/**
	 * test if two dates are equals. 
	 * a test between a date and an Object type
	 */
	@Test
	public void testequalstoFalseCaseWhenTheObjectIsNotInstanceOfDate() {
		Object object = new Object();
		assertFalse( d1.equals(object) );	
	}
	
	/**
	 * test which date will be after a number of days
	 */
	@Test
	public void testDateAfterNbDay() {
		Date newDateAfterNbDay = d1.dateAfterNbDay(1);
		assertEquals(newDateAfterNbDay, new Date(28, Month.February, 2020));
		Date dateAfterNbDay = d1.dateAfterNbDay(5);
		assertEquals(dateAfterNbDay, new Date(3, Month.March, 2020));
	}
	
	/**
	 * test if the argument is illegal, then an exception is raised
	 */
	@Test(expected=IllegalArgumentException.class)
	public void testDateAfterNbDayException() {
		int nbOfDay = -5;
		d1.dateAfterNbDay(nbOfDay);
	}

}
