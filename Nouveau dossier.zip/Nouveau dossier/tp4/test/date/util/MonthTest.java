package date.util;

import org.junit.*;
import date.util.Month;
import static org.junit.Assert.*;

/**
 * a Test Class for Month
 * */
public class MonthTest {
	private Month november;
	private Month february;
	private Month december;
	
	@Before
	/**
	 * initialization of the instances
	 */
	public void initialization() {
		november = Month.November;
		february = Month.February;
		december = Month.December;
	}
	
    /**
     * test if the number of days of the month are initially correct
     */
	@Test
	public void testgetNbOfDays() {
		assertEquals(november.getNbOfDays(2020), 30);
		assertEquals(february.getNbOfDays(2019), 28);
	}
	
	/**
	 * we test if a year is leaper
	 */
	@Test
	public void testIsLeaperYearTrueCase() {
		assertTrue(Month.isLeapYear(2016));
		assertTrue(Month.isLeapYear(2012));
	}
	
	/**
	 * we test if a year is not leaper
	 */
	@Test
	public void testIsLeaperYearFalseCase() {
		assertFalse(Month.isLeapYear(2019));
		assertFalse(Month.isLeapYear(2018));
	}
	
	/**
	 * we test the month following the current month
	 */
	@Test
	public void testNext() {
		assertSame(november.next(), Month.December);
		assertSame(december.next(), Month.January);
	}

}
