package example;
import org.junit.*;
import static org.junit.Assert.*;
import example.util.*;
import example.Robot;

public class RobotTest {

	/**tests if the robot takes the box when its not carrying another box*/
	@Test
	public void testTakeWhenRobotNotCarryingBox() {
		Robot robot = new Robot();
		Box box = new Box(10);
		robot.take(box);
		assertEquals(box,robot.getCarriedBox());
	}

	/**tests if the robot doesnt take another box when its already carrying one*/
	@Test
	public void testTakeWhenRobotIsCarryingBox() {
		Robot robot = new Robot();
		Box box1 = new Box(10);
		Box box2= new Box(15);
		robot.take(box1);
		robot.take(box2);
		assertEquals(box1,robot.getCarriedBox());
	}

	/**tests if carryBox() returns true when a box is carried by the robot*/
	@Test
	public void testCarryBoxWhenRobotNotCarryingBox() {
		Robot robot = new Robot();
		assertFalse(robot.carryBox());
	}

	/**tests if carryBox() returns false when no box is carried by the robot*/
	@Test
	public void testCarryBoxWhenRobotIsCarryingBox() {
		Robot robot = new Robot();
		Box box = new Box(5);
		robot.take(box);
		assertTrue(robot.carryBox());
	}

	/**tests if the robo puts the box on the belt */
	@Test
	public void testPutOnWhenRobotPutsTheBox() {
		Robot robot = new Robot();
		Box box1 = new Box(10);
		robot.take(box1);
		ConveyerBelt belt = new ConveyerBelt(100);
		robot.putOn(belt);
		assertFalse(robot.carryBox());
	}

	/**tests if the box is not put on when the belt is full*/
	@Test
	public void testPutOnWhenBeltIsFull() {
		Robot robot = new Robot();
		Box box = new Box(10);
		robot.take(box);
		ConveyerBelt belt = new ConveyerBelt(100);
		Box box1 = new Box(10);
		Box box2 = new Box(10);
		belt.receive(box1);
		belt.receive(box2);
		robot.putOn(belt);
		assertEquals(box,robot.getCarriedBox());
	}

	/**tests if the box is not put on when the box is too heavy*/
	@Test
	public void testPutOnWhenBoxIsHeavy() {
		Robot robot = new Robot();
		Box box = new Box(20);
		robot.take(box);
		ConveyerBelt belt = new ConveyerBelt(10);
		robot.putOn(belt);
		assertEquals(box,robot.getCarriedBox());
	}

	// ---Pour permettre l'exécution des test----------------------
	public static junit.framework.Test suite() {
			return new junit.framework.JUnit4TestAdapter(RobotTest.class);
	}




}
