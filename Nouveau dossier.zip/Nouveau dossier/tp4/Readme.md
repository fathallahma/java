# TP4

## Auteurs

 -Manal Laghmich
 -Reda Id idtaleb

 groupe : 4

## Introduction

Ce TP avait plusieurs objectifs, le TP préliminaire nous apprenait d'abord à organiser notre dossier tp4, en créant notamment plusieurs répertoires:
  * un dossier *src* pour les sources
  * un dossier *test* pour les tests.

De plus, ce TP préliminaire nous apprend aussi ce que sont les paquetages, permettant d'organiser nos différents fichiers, ainsi que la syntaxe des tests de nos différentes méthodes.

Tout ces pratiques sont mises en application dans la première partie du TP4, où l'on manipule une classe Robot et une classe Box, nous écrivons alors nos premiers tests,nous apprenons à compiler les fichiers sources, les tests, nous écrivons également une méthode main qui sera soit executée "manuellement" soit grâce à un fichier appli.jar que nous avons également appris à créer.

La deuxième partie du TP nous donne pour objectif de créer les classes Date et Month vues plus tôt en TD, ainsi qu'une classe DateMain, faisant plusieurs manipulations sur les objets Date.


## HOW TO


### récupération des données

Pour récupérer les données du projet, suivez les étapes suivantes :

* Si vous avez déjà une version locale du dépôt Git :
    * il vous suffit d'exécuter la commande shell suivante :
        ``` bash
        $ git pull
        ```
    Vous aurez ensuite accès à tous les fichiers du TP, et vous pourrez l'ouvrir dans
    un éditeur de texte.


* Si vous n'avez pas encore de version locale du dépôt :
    * Exécutez la commande suivante pour créer une version locale du dépôt dans
    le dossier *dossier-tp* :
        ```bash
        $ git clone https://gitlab-etu.fil.univ-lille1.fr/laghmich/laghmich-idtaleb-poo.git dossier-tp
        ```
        (**Attention**, le dossier doit être vide originellement)

    * Si vous préférez utiliser votre clé SSH (si elle est configurée sur votre
      [compte](https://docs.gitlab.com/ee/gitlab-basics/create-your-ssh-keys.html)) :

        ```bash
        $ git clone git@gitlab-etu.fil.univ-lille1.fr:laghmich/laghmich-idtaleb-poo.git
        ```
    Vous aurez de cette manière accès aux différents fichiers du projet. Pour mettre
     à jour ces fichiers, utilisez la commande précisée ci-dessus.

### Generation de la documentation
* Pour gener la documentation,Placez-vous dans le dossier tp4/src et passez la commande suivante :
  * pour date :
  ```bash
  $ javadoc -d ../docs -subpackages date
  ```
  * pour example :
  ```bash
  $ javadoc -d ../docs -subpackages example
  ```
 Pour la consulter, ouvrez le fichier index.html qui se trouve dans le dossier docs.

### Compilation des sources du projet (à faire en premier)

* Pour compiler les sources du projet, placez-vous a la racine du projet et passez les commandes suivantes :

  ```bash
  $ mkdir classes
  ```
  Ensuite, mettez vous dans le dossier src et passez la commande suivante:
    * pour date :
    ```bash
    $ javac date/*.java -d ../classes
    ```
    * pour example :
    ```bash
    $ javac example/*.java -d ../classes
    ```

### Compilation et execution des tests

* Pour compiler une classe de test, placez-vous dans le dossier tp4/
et éxécutez la commande suivante:

  ```bash
  $ javac -classpath test-1.7.jar test/NomDeLaClasseDeTest.java
  ```
  *  exemple: Pour compiler la classe MonthTest ,éxécutez la commande :

  ```bash
  $ javac -classpath test-1.7.jar test/date/util/MonthTest.java
  ```
* Pour executer une classe de test, placez-vous dans le dossier tp4/
et éxécutez la commande suivante:

  ```bash
  $ java -jar test-1.7.jar NomDeLaClasseDeTest
  ```
  *  exemple: Pour executer la classe MonthTest ,éxécutez la commande :
  ```bash
  $ java -jar test-1.7.jar MonthTest
  ```

### Execution du programme avec le .jar executable

  placez-vous dans le dossier tp4/classes et ensuite, passez la commande suivante:
  * pour example :
  ```bash
  $ jar cvfm ../example.jar ../manifest-ex example
  ```  
  * pour date :
  ```bash
  $ jar cvfm ../date.jar ../manifest-dt date
  ```  
### Execution du programme sans le .jar executable

  * pour example :
  ```bash
  $ java -classpath classes example.Robot
  ```  
  * pour date :
  ```bash
  $ java -classpath classes date.DateMain
  ```  

### Usage du makefile

Le Makefile se trouvant dans le répertoire TP4, il faut y accéder par la commande cd TP4 après avoir récupéré le depot distant grâce à git pull, toutes les commandes du Makefile se font dans le répertoire.

##### Compilation des sources
  Pour compiler les sources du projet, placez-vous a la racine du projet et passez las commande suivante pour compiler toutes les classes du projets :
  ```bash
  $ make compileAll
  ```  
  Pour compiler une seule classe passez la commande :
  ```bash
  $ make compile'NomDeLaClasse'
  ```  
  exemple:
  ```bash
  $ make compileRobot
  ```  
##### Generation de la doc
  Pour generer la doc , passez la commande suivante:
  ```bash
  $ make doc
  ```  
Un dossier docs est alors créé dans TP4, dans ce fichier se trouvent plusieurs fichiers en .html, ouvrir le fichier index.html vous permet de consulter la doc.

##### Execution et compilation des tests
La commande suivante permet de compiler et d'executer les tests du projet:
  ```bash
  $ make allTests
  ```  
  Pour compiler et executer une seule classe de test passez la commande :
  ```bash
  $ make test'NomDeLaClasse'
  ```  
  **Attention !** La compilation des tests exige normalement que les fichiers sources soient d'abord compilés,.

##### Execution du programme avec le .jar executable
  * pour example:
  La commande suivante permet de créer le fichier example.jar executable et de l'executer:
  ```bash
  $ make archiveExample
  ```
  * pour date:
  La commande suivante permet de créer le fichier date.jar executable et de l'executer:
  ```bash
  $ make archiveDate
  ```
##### Execution du programme sans le .jar executable
  * pour example :
  ```bash
  $ make example
  ```  
  * pour date :
  ```bash
  $ make Date
  ```  
##### Nettoyage du TP4
La commande suivante supprime le dossier classes, le dossier docs, le fichier .jar et les fichiers .class, ces fichiers pouvant tous être recréés avec les commandes ci-dessus :
  ```bash
  $ make clean
  ```  
