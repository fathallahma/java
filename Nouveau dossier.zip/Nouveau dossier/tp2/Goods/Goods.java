
/**
 * A class of goods.
 *
 * @author Manal Laghmich and Reda Idtaleb
 * @version 30/01/2020
 */
public class Goods
{
    // instance variables - replace the example below with your own
    private double value;
    private String name;

    /**
     * Constructor for objects of class Goods
     * @param the name of the goods
     */
    public Goods(String name)
    {
        this.value=0;
        this.name=name;
    }
    
    /**
     * Constructor for objects of class Goods
     * @param the name of the goods
     * @param the value of the goods in euro 
     */
    public Goods(double value, String name){
        this.value=value;
        this.name=name;
    }
    
    /**returns the value of the goods in euros
     * @return the value of the goods
     */
    public double getValue(){
        return this.value;
    }
    
    /**returns the name of the goods 
    * @return the name of the goods
    */
    public String getName(){
        return this.name;
    }
    
    /** sets the value of the goods
     * @param v the value to set
     */
    public void setValue(double v){
        this.value=v;
    }
    
    /** sets the name of the goods
    * @param name the value to set
    */
    public void setValue(String n){
        this.name=n;
    }
    
    /** returns a sentence informing the goods name and value
     * @return a sentence informing the goods name and value
    */
    public String toString(){
        return "the goods "+this.name+" costs "+this.value;
    }
    
    /** returns the TTC value of the goods
     * @return the TTC value of the goods
     */
    public double getTTCValue(){
        return this.value*1.20;
    }
    

}
