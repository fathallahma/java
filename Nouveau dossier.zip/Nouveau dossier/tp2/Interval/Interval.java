
/**
 * A class of Interval
 *
 * @author Manal Laghmich - Reda Idtaleb
 * @version 31/01/2020
 */

public class Interval
{
    // instance variables - replace the example below with your own
    /**the beginning od the interval*/
    private int begin;
    /** the end of the interval*/
    private int end;

    /**
     * Constructor for objects of class Interval
     * @param begin the beginning of the interval
     * @param end the end of the inetrval
     */
    public Interval(int begin, int end)
    {
        this.begin=begin;
        this.end=end;
    }

    /** returns the beginning of the interval
     * @return the beginning of the interval
     */
    public int getBegin(){
        return this.begin;
    }
    
    /** returns the end of the interval
     * @return the end of the interval
     */
    public int getEnd(){
        return this.end;
    }
    
        /** returns a boolean indicating if the interval is empty or not\
    *@return true if the interval is empty, false if not
    */
    public boolean isEmpty(){
        return begin>end;
    }
    
    /**returns the length of the interval
     * @return the length of the interval
     */
    public int getLength(){
        if(this.isEmpty()){
            return 0;
        }
        else {return this.end-this.begin;}
    }
    
    /** return a boolean indicating if the interval contains a value
    * @param val the value
    * @return true if the interval contains the value, false if not
    */
    public boolean isInside(int val){
        return val<=end && val>=begin;
    }
    
    /** returns a boolean indicating if two intervals are equals
     * @param o the object (interval) to compare to
     * @returns true if the two intervals are equal , false if not
     * 
     */
    public boolean equals(Object o){
        if (!(o instanceof Interval)){
            return false;
        }
        else {
            Interval other= (Interval) o;
            return this.begin==other.getBegin() && this.end==other.getEnd();
        }
    }
    
    /** description of the interval
     * @returns the description of the interval
     */
    public String toString(){
        return "["+this.begin+","+this.end+"]";
    }
    
    /** creates an inter Interval from two intervals
     * @param other an other interval
     * @return the inter Interval
     */
    public Interval createInter(Interval other){
        int b=Math.max(this.begin,other.begin);
        int e=Math.min(this.end,other.end);
        return new Interval(b,e);
    }
    
    /**extends the inteval with a given value
     * @param val the value
     * @returns the new extended interval
     */
    public Interval extendInterval(int val){
        if (this.isEmpty()){
            return this;
        }
        else {
            return new Interval(this.begin,this.end+val);
        }
    }
    
    /** returns a boolean indicating if two intervals are disjoin
     * @param other the other interval
     * @return a true if the intervals are disjoinm false if not
     */
    public boolean disjoin(Interval other){
        return other.getBegin()>this.end || other.getEnd()<this.begin;
    }
    
    /** Merges two intervals
     * @param other the other interval
     * @returns the merged interval or one of the two if the other is empty
     */
    public Interval Merge(Interval other){
        if(other.isEmpty()){
            return this;
        }
        else if (this.isEmpty()){
            return other;
        }
        else{
            int b=Math.min(this.begin,other.begin);
            int e=Math.max(this.end,other.end);
            return new Interval(b,e);
        }
    
    }
}
