# TP2

## Auteurs

 -Manal Laghmich
 -Reda Id idtaleb

 groupe : 4

## Introduction
  Le TP porte sur la création de
  *quelques classes* :
  Complex, Interval : Vues en TD.
  Stock, goods.
  et le *mini-projet* : Light, toujours avec le logiciel bluej.


## HOW TO


### récupération des données

Pour récupérer les données du projet, suivez les étapes suivantes :

* Si vous avez déjà une version locale du dépôt Git :
    * il vous suffit d'exécuter la commande shell suivante :
        ``` bash
        $ git pull
        ```
    Vous aurez ensuite accès à tous les fichiers du TP, et vous pourrez l'ouvrir dans
    un éditeur de texte.


* Si vous n'avez pas encore de version locale du dépôt :
    * Exécutez la commande suivante pour créer une version locale du dépôt dans
    le dossier *dossier-tp* :
        ```bash
        $ git clone https://gitlab-etu.fil.univ-lille1.fr/laghmich/laghmich-idtaleb-poo.git dossier-tp
        ```
        (**Attention**, le dossier doit être vide originellement)

    * Si vous préférez utiliser votre clé SSH (si elle est configurée sur votre
      [compte](https://docs.gitlab.com/ee/gitlab-basics/create-your-ssh-keys.html)) :

        ```bash
        $ git clone git@gitlab-etu.fil.univ-lille1.fr:laghmich/laghmich-idtaleb-poo.git
        ```
    Vous aurez de cette manière accès aux différents fichiers du projet. Pour mettre
     à jour ces fichiers, utilisez la commande précisée ci-dessus.
