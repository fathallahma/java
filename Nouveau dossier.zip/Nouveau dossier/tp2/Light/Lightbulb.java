
/**
 * A class of a Light bulb
 *
 * @author Manal Laghmich and Reda Idtaleb
 * @version 31/01/2020
 * */
public class Lightbulb
{
    // instance variables - replace the example below with your own
    /**the lightbulb's power*/
    private double power;
    /** the lightbulbs color*/
    private String color;
    /** a boolean indicating if the light bulb is On or Off*/
    private boolean isOn;

    /**
     * Constructor for objects of class Lightbulb
     */
    public Lightbulb(double power,String color)
    {
        this.power=power;
        this.color=color;
        this.isOn=false;
    }
    
    /**returns the light bulb's power
     * @return the light bulb's power
     */
    public double getPower(){
        return this.power;
    }
    
    /**returns the light bulb's color
     * @return the light bulb's color
     */
    public String getColor(){
        return this.color;
    }
    
    /**returns a boolean indicating if the lightbulb is on or off
     * @return True if the light bulb is on , false if it's off
     */
    public boolean isOn(){
        return this.isOn;
    }
    
    /** turns the light bulb on
    */
    public void turnON(){
        this.isOn=true;
    }
    
    /** turns the light bulb off
    */
    public void turnOFF(){
        this.isOn=false;
    }

    
    /** a sentence describing the light bulb
     * @return a sentence describing the light bulb
     */
    public String toString(){
        return "this light bulb is "+this.color+". Its power is "+this.power+" It is acurrently "+this.isOn;
    }
}
