
/**
 * A class of a LightString
 *
 * @author Manal Laghmich - Reda IdTaleb
 * @version 31/01/2020
 */
public class LightString
{
    // instance variables - replace the example below with your own
    
    private Lightbulb[] lightString;
    /** the number of the lightbulbs in the light String*/
    private int nb;
    private boolean isOn;

    /**
     * Constructor for objects of class LightString
     * @param the number of light bulbs
     */
    public LightString(int n)
    {
        this.nb=n;
        this.lightString=new Lightbulb[nb];
        for(int i=0; i<nb; i++){
            this.lightString[i]=new Lightbulb(1,"white");
        }
    }
    
    /**
     * returns a certain lightbulb based on its index
     * @param the index of the light bulb
     * @returns the lightbulb or null is the index is invalid
     */
    public Lightbulb getTheLightBulb(int i){
        if(i>=0 && i<this.nb){
            return this.lightString[i];
        }
        else return null;
    }
    
    /** replace the n-th lightbulb of the light string by the given lightbulb.
    * Nothing happens if i is not a valid index.
    * @param i the number of the lightbulb to be changed (first has number 1)
    * @param theBulb the new lightbulb
    */
    public void changeLightbulb(int i, Lightbulb theBulb){
        if(i>=1 && i<=this.nb){
            this.lightString[i-1]=theBulb;
        }
    }
    
    /** turns on the ligjtString
       */
    public void turnON(){
        for(int i=0; i<this.nb; i++){
            this.lightString[i].turnON();
        }
        this.isOn=true;
    }
    
    /**turns off the lightString
       */
    public void turnOFF(){
        for(int i=0; i<this.nb; i++){
            this.lightString[i].turnOFF();
        }
        this.isOn=false;
    }
    
    /** returns the consumed power by the lightString
     * @return the consumed power by the light string
     */
    public double getConsumedPower(){
        if(this.isOn){
            return this.nb*1;
        }
        else {return 0;}
    }
    
    


}
