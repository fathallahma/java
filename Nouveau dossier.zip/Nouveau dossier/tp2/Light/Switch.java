
/**
 * A class of a Switch
 *
 * @author Manal Laghmich - Reda Idtaleb
 * @version 31/01/2020
 */
public class Switch
{
    /** the light bulb to turn On or Off*/ 
    private Lightbulb lightbulb;
    
    /**
     * Constructor for objects of class Switch
     * @param lightbulb the light bulb to turn on or off
     */
    public Switch(Lightbulb lightbulb)
    {
        this.lightbulb=lightbulb;
    }

    /**
     *switches the state of the lightbulb from On to Off and vice versa
     */
    public void switchState()
    {
        if (this.lightbulb.isOn()){
            this.lightbulb.turnOFF();
        }
        else {this.lightbulb.turnON();}
    }
}
