
/**
 * A class of a stock.
 *
 * @author Manal Laghmich - Reda Idtaleb
 * @version 30/01/2020
 */
public class Stock
{

    private int quantity;

    /**
     * Constructor for objects of class Stock
     */
    public Stock()
    {
        this.quantity = 0 ;
    }
    
    /** Creates a stock with a certain quantity 
     * given in parameter
     * @param q the quantity od the stock
     */
    public Stock(int q){
        this.quantity=q;
    }

    /** returns the quantity of the stock
     * @return the stock's quantity
     */
    public int getQuantity () {
        return this.quantity ;
    }
    
    /** adds n elements to the stock
     * @param n the number of elements to add
     */
    public void add(int n){
        this.quantity=this.quantity+n;
    }
    
    /** removes n elements from the stock
     * @param n the number of elements to remove
     * @return the number of the removed elements
     */
    public int remove(int n){
        int res=0;
        if(n<= this.quantity){
            this.quantity=this.quantity-n;
            res=n;
        }
        else {
            res=this.quantity;
            this.quantity=0;
        }
        return res;
    }
      
    /** returns a sentence informing the stock's quantity
     * @return a sentence informing the stock's quantity
     */
    public String toString(){
        return "the stock’s quantity is "+this.quantity;  
    }
    
    
    
} 
